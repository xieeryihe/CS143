#!/usr/bin/python2.6
# test_compare.py
import os
FindPath = "/home/compilers/cool/examples/"
# arith.cl, atoi.cl, atoi_test.cl, book_list.cl, cells.cl, complex.cl,
# cool.cl ,graph.cl, hairyscary.cl, hello_world.cl, io.cl, lam.cl
# life.cl, list.cl, new_complex.cl, palindrome.cl, primes.cl, sort_list.cl
filename = "sort_list.cl"

stdOutput = os.popen("reflexer " + FindPath + filename).read()
myOutput = os.popen("./lexer " +  FindPath + filename).read()

file_my = open("my.txt","w")
file_std = open("std.txt","w")

file_my.write(myOutput)
file_std.write(stdOutput)

os.popen("cp my.txt ../../sf_shared")
os.popen("cp std.txt ../../sf_shared")

beginIndex = myOutput.index("#name")
myOutput = myOutput[beginIndex:]

while True:
    try:
        myEnd = myOutput.index("\n")
        stdEnd = stdOutput.index("\n")
    except:
        break
    if myOutput[0 : myEnd] != stdOutput[0 : stdEnd]:
        print("my flex ", myOutput[0 : myEnd])
        print("std flex", stdOutput[0 : stdEnd])
        print("")
    myOutput = myOutput[myEnd + 1 :]
    stdOutput = stdOutput[stdEnd + 1 :]
