#!/usr/bin/python2.6
# test_compare.py
import os
FindPath = "/home/compilers/cool/examples/"
FileNames = os.listdir(FindPath)
int 
for file in FileNames:
    if file.find('.cl') < 0:
        continue
    # print file
    stdOutput = os.popen("reflexer " + FindPath + file).read()
    myOutput = os.popen("./lexer " +  FindPath + file).read()

    beginIndex = myOutput.index("#name")
    myOutput = myOutput[beginIndex:]

    while True:
        try:
            myEnd = myOutput.index("\n")
            stdEnd = stdOutput.index("\n")
        except:
            break
        if myOutput[0 : myEnd] != stdOutput[0 : stdEnd]:
            print(file)
            break
            # print("my flex ", myOutput[0 : myEnd])
            # print("std flex", stdOutput[0 : stdEnd])
            # print("")
        myOutput = myOutput[myEnd + 1 :]
        stdOutput = stdOutput[stdEnd + 1 :]