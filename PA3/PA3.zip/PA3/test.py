import os
import sys


def test_case(lexer_path, parser_path, pa3_parser_path, case_path):
    result = os.popen('{} {} | {} > /tmp/output1 2>&1; {} {} | {} > /tmp/output2 2>&1; diff /tmp/output1 /tmp/output2'.format(lexer_path, case_path, parser_path, lexer_path, case_path, pa3_parser_path))
    data = result.read()
    if len(data) == 0:
        return True
    else:
        return False

def test_pa3(project_dir):
    pa3_dir = os.path.join(project_dir, 'assignments/PA3')
    bin_dir = os.path.join(project_dir, 'bin')
    test_cases_dir = os.path.join(project_dir, 'lab3_test_cases')

    if not os.path.exists(test_cases_dir):
        print('plz put the test cases dir under the root of project...')
        exit(0)

    test_cases = os.listdir(test_cases_dir)
    test_cases_pathes = [os.path.join(test_cases_dir, test_case) for test_case in test_cases]

    # make parser
    print('start make parser...')
    os.system('cd {} && rm parser && make parser'.format(pa3_dir))
    lexer = os.path.join(bin_dir, 'lexer')
    parser = os.path.join(bin_dir, 'parser')
    pa3_parser = os.path.join(pa3_dir, 'parser')
    print('make lexer successfully!')

    # test
    print('start testing...')
    count = len(test_cases_pathes)
    successful_count = 0
    fail_pathes = []

    for case in test_cases_pathes:
        if test_case(lexer, parser, pa3_parser, case):
            successful_count += 1
            print('Test case: {} pass :)'.format(case))
        else:
            fail_pathes.append(case)
            print('Test case: {} fail :('.format(case))

    print('Your score:\nPass: {}/{}\nFail:\n{}'.format(successful_count, count, '\n'.join(fail_pathes)))


if __name__ == '__main__':
    project_dir = "/home/wyc/Desktop/cool-compiler/"
    if not os.path.isdir(project_dir):
        print('Input the root path of your cool project!')
        exit(1)
    test_pa3(project_dir)
