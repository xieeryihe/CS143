//本代码还有很多不完善的地方。
//好多逻辑检查，尤其是越写在前面的，代码越原始。
//后来是写到后面，实在没办法了，才写的函数，然后重构了一部分代码。
//很多调试过程的注释也没有去掉，实在是太多了，就这样吧（摆了）。
//希望后人不要学我。
//要用到的函数，辅助函数都在semant.h中标明。


#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include "semant.h"
#include "utilities.h"


extern int semant_debug;
extern char *curr_filename;

//////////////////////////////////////////////////////////////////////
//
// Symbols
//
// For convenience, a large number of symbols are predefined here.
// These symbols include the primitive type and method names, as well
// as fixed names used by the runtime system.
//
//////////////////////////////////////////////////////////////////////
static Symbol 
    arg,
    arg2,
    Bool,
    concat,
    cool_abort,
    copy,
    Int,
    in_int,
    in_string,
    IO,
    length,
    Main,
    main_meth,
    No_class,
    No_type,
    Object,
    out_int,
    out_string,
    prim_slot,
    self,
    SELF_TYPE,
    Str,
    str_field,
    substr,
    type_name,
    val;
//
// Initializing the predefined symbols.
//
static void initialize_constants(void)
{
    arg         = idtable.add_string("arg");
    arg2        = idtable.add_string("arg2");
    Bool        = idtable.add_string("Bool");
    concat      = idtable.add_string("concat");
    cool_abort  = idtable.add_string("abort");
    copy        = idtable.add_string("copy");
    Int         = idtable.add_string("Int");
    in_int      = idtable.add_string("in_int");
    in_string   = idtable.add_string("in_string");
    IO          = idtable.add_string("IO");
    length      = idtable.add_string("length");
    Main        = idtable.add_string("Main");
    main_meth   = idtable.add_string("main");
    //   _no_class is a symbol that can't be the name of any 
    //   user-defined class.
    No_class    = idtable.add_string("_no_class");
    No_type     = idtable.add_string("_no_type");
    Object      = idtable.add_string("Object");
    out_int     = idtable.add_string("out_int");
    out_string  = idtable.add_string("out_string");
    prim_slot   = idtable.add_string("_prim_slot");
    self        = idtable.add_string("self");
    SELF_TYPE   = idtable.add_string("SELF_TYPE");
    Str         = idtable.add_string("String");
    str_field   = idtable.add_string("_str_field");
    substr      = idtable.add_string("substr");
    type_name   = idtable.add_string("type_name");
    val         = idtable.add_string("_val");
}



ClassTable::ClassTable(Classes classes) : semant_errors(0) , error_stream(cerr) {
    /* Fill this in */
    classlist = classes; //一定要先赋值，否则classlist为null，就没办法调用append
    install_basic_classes();
    // cout<< classlist->len()<<endl;

    gClasslist = this->classlist;
    gClasstable = this;

    //随便找一个类把filename取出来就行
    gfilename = classlist->nth(0)->get_filename();
    gSymboltable = new SymbolTable<Symbol,Entry>();
}

void ClassTable::install_basic_classes() {

    // The tree package uses these globals to annotate the classes built below.
   // curr_lineno  = 0;
    Symbol filename = stringtable.add_string("<basic class>");
    
    // The following demonstrates how to create dummy parse trees to
    // refer to basic Cool classes.  There's no need for method
    // bodies -- these are already built into the runtime system.
    
    // IMPORTANT: The results of the following expressions are
    // stored in local variables.  You will want to do something
    // with those variables at the end of this method to make this
    // code meaningful.

    // 
    // The Object class has no parent class. Its methods are
    //        abort() : Object    aborts the program
    //        type_name() : Str   returns a string representation of class name
    //        copy() : SELF_TYPE  returns a copy of the object
    //
    // There is no need for method bodies in the basic classes---these
    // are already built in to the runtime system.

    Class_ Object_class =
	class_(Object, 
	       No_class,
	       append_Features(
			       append_Features(
					       single_Features(method(cool_abort, nil_Formals(), Object, no_expr())),
					       single_Features(method(type_name, nil_Formals(), Str, no_expr()))),
			       single_Features(method(copy, nil_Formals(), SELF_TYPE, no_expr()))),
	       filename);

    // 
    // The IO class inherits from Object. Its methods are
    //        out_string(Str) : SELF_TYPE       writes a string to the output
    //        out_int(Int) : SELF_TYPE            "    an int    "  "     "
    //        in_string() : Str                 reads a string from the input
    //        in_int() : Int                      "   an int     "  "     "
    //
    Class_ IO_class = 
	class_(IO, 
	       Object,
	       append_Features(
			       append_Features(
					       append_Features(
							       single_Features(method(out_string, single_Formals(formal(arg, Str)),
										      SELF_TYPE, no_expr())),
							       single_Features(method(out_int, single_Formals(formal(arg, Int)),
										      SELF_TYPE, no_expr()))),
					       single_Features(method(in_string, nil_Formals(), Str, no_expr()))),
			       single_Features(method(in_int, nil_Formals(), Int, no_expr()))),
	       filename);  

    //
    // The Int class has no methods and only a single attribute, the
    // "val" for the integer. 
    //
    Class_ Int_class =
	class_(Int, 
	       Object,
	       single_Features(attr(val, prim_slot, no_expr())),
	       filename);

    //
    // Bool also has only the "val" slot.
    //
    Class_ Bool_class =
	class_(Bool, Object, single_Features(attr(val, prim_slot, no_expr())),filename);

    //
    // The class Str has a number of slots and operations:
    //       val                                  the length of the string
    //       str_field                            the string itself
    //       length() : Int                       returns length of the string
    //       concat(arg: Str) : Str               performs string concatenation
    //       substr(arg: Int, arg2: Int): Str     substring selection
    //       
    Class_ Str_class =
	class_(Str, 
	       Object,
	       append_Features(
			       append_Features(
					       append_Features(
							       append_Features(
									       single_Features(attr(val, Int, no_expr())),
									       single_Features(attr(str_field, prim_slot, no_expr()))),
							       single_Features(method(length, nil_Formals(), Int, no_expr()))),
					       single_Features(method(concat, 
								      single_Formals(formal(arg, Str)),
								      Str, 
								      no_expr()))),
			       single_Features(method(substr, 
						      append_Formals(single_Formals(formal(arg, Int)), 
								     single_Formals(formal(arg2, Int))),
						      Str, 
						      no_expr()))),
	       filename);
    //classes = append_Classes(classes,object_classes);
    Classes object_classes = new single_list_node<Class_>(Object_class);//要组织成Classes类型，也即列表指针类型，才能调用append
    Classes IO_classes = new single_list_node<Class_>(IO_class);
    Classes Int_classes = new single_list_node<Class_>(Int_class);
    Classes Bool_classes = new single_list_node<Class_>(Bool_class);
    Classes Str_classes = new single_list_node<Class_>(Str_class);
    
    classlist = classlist->append(classlist,object_classes);
    classlist = classlist->append(classlist,IO_classes);
    classlist = classlist->append(classlist,Int_classes);
    classlist = classlist->append(classlist,Bool_classes);
    classlist = classlist->append(classlist,Str_classes);

}

////////////////////////////////////////////////////////////////////
//
// semant_error is an overloaded function for reporting errors
// during semantic analysis.  There are three versions:
//
//    ostream& ClassTable::semant_error()                
//
//    ostream& ClassTable::semant_error(Class_ c)
//       print line number and filename for `c'
//
//    ostream& ClassTable::semant_error(Symbol filename, tree_node *t)  
//       print a line number and filename
//
///////////////////////////////////////////////////////////////////

ostream& ClassTable::semant_error(Class_ c)
{                                                             
    return semant_error(c->get_filename(),c);
}    

ostream& ClassTable::semant_error(Symbol filename, tree_node *t)
{
    error_stream << filename << ":" << t->get_line_number() << ": ";
    return semant_error();
}

ostream& ClassTable::semant_error()                  
{                                                 
    semant_errors++;                            
    return error_stream;
} 



/*   This is the entry point to the semantic checker.

     Your checker should do the following two things:

     1) Check that the program is semantically correct
     2) Decorate the abstract syntax tree with type information
        by setting the `type' field in each Expression node.
        (see `tree.h')

     You are free to first do 1), make sure you catch all semantic
     errors. Part 2) can be done in a second stage, when you want
     to build mycoolc.
 */

void program_class::semant()
{
    initialize_constants();

    /* ClassTable constructor may do some semantic analysis */
    ClassTable *classtable = new ClassTable(classes);

    /* some semantic analysis code may go here */
    //classtable->class_main_check();

    classtable->class_check();

    if (classtable->errors()) {
	cerr << "Compilation halted due to static semantic errors." << endl;
	exit(1);
    }
}

//-------------------------------
//辅助函数


int find_class(Classes classes, char* class_name){
    int i = 0;
    for(i = classes->first(); classes->more(i); i = classes->next(i)){
        
        Symbol name = classes->nth(i)->get_name();
        //cout<<"name "<<name->get_string()<<endl;
        if(same_symbol(name,class_name))
            return i;
    }
    return -1;
}
int find_class(Classes classes, Symbol class_name){
    char* name = class_name->get_string();
    return find_class(classes,name);
}
Class_ get_parent_class(Classes classes, Class_ c){
    /*
    Class_ temp_class = c, ret_class;
    Symbol parent_name = c->get_parentname();
    int index = find_class(classes, parent_name);
    ret_class = classes->nth(index);
    return ret_class;
    */
    return classes->nth(find_class(classes, c->get_parentname()));
}

//找i索引的下一个方法
int next_method(Features features, int i){
    for (i = i+1; features->more(i); i = features->next(i)){
        
        if (features->nth(i)->get_feature_type()==METHOD)
            return i;
    }
    return -1;
}
//找i索引的下一个属性
int next_attr(Features features, int i){
    for (i = i+1; features->more(i); i = features->next(i)){
        if (features->nth(i)->get_feature_type()==ATTR)
            return i;
    }
    return -1;
}

int find_method(Features features, char* method_name){
    int i = -1;
    while ( (i = next_method(features,i)) >= 0 )
    {
        Symbol name = features->nth(i)->get_name();
        if (name->equal_string(method_name,strlen(method_name)))
            return i;
    }
    return -1;
}
int find_method(Features features, Symbol method_name){
    char* name = method_name->get_string();
    return find_method(features, name);
}

//目标类及其祖先中找对应方法，找到则返回对应类，否则为NULL
Class_ method_exist(Class_ c, Symbol s){
    int i = 0;
    Class_ temp_class = c;

    while (1)
    {
        //cout<<"find in : "<<temp_class->get_name()->get_string()<<endl;
        
        Features features = temp_class->get_features();
        //找到则返回
        //cout<<"here"<<endl;
        if (find_method(features, s)>=0)
        {
            //cout<<"find!!!! in: "<<temp_class->get_name()->get_string()<<endl;;
            return temp_class;
        }
        //cout<<"here"<<endl;
        //循环终止条件是追溯到Object
        if (same_symbol(temp_class->get_name(), Object))
        {
            break;
        }
        //找不到则继续向上追溯
        Symbol parent_name = temp_class->get_parentname();
        //cout<<parent_name->get_string()<<endl;
        temp_class = gClasslist->nth(find_class(gClasslist, parent_name));

    }
    return NULL;
    
}
int find_attr(Features features, char* attr_name){
    int i = -1;
    while ( (i = next_attr(features,i)) >= 0 )
    {
        Symbol name = features->nth(i)->get_name();
        if (name->equal_string(attr_name,strlen(attr_name)))
            return i;
    }
    return -1;
    
}
int find_attr(Features features, Symbol attr_name){
    char* name = attr_name->get_string();
    return find_attr(features, name);
}

//在目标classes中，将c及其祖先的所有attr加入到符号表t中
void add_all_attr(SymbolTable<Symbol,Entry>* t, Classes classes, Class_ c){
    Class_ temp_class = c;
    Features features;
    Feature feature;
    attr_class* attr;
    int i = 0;
    while (1)
    {
        features = temp_class->get_features();
        //遍历属性列表，找出成员变量，并加入table
        i = -1;
        while ( (i = next_attr(features,i)) >= 0 )
        {
            feature = features->nth(i);
            attr = static_cast<attr_class*>(feature);
            t->addid(attr->get_name(), attr->get_type_decl());
        }
        
        //追溯到Object即停止
        if (same_symbol(temp_class->get_name(), Object))
        {
            break;
        }
        //否则继续向上追溯
        temp_class = get_parent_class(classes, temp_class);
        
    }
    return;
}

// 找最小的共同父类
Symbol lowest_common_ancestor(Symbol s1, Symbol s2){
    int i=0,j=0;
    Symbol outer = s1,inner = s2;
    char* outer_name, *inner_name;
    Class_ outer_class, inner_class;
    
    //cout<<endl;
    //cout<<"Symbol : "<< s1->get_string()<<"   "<<s2->get_string()<<endl;

    while (1)
    {
        if (outer->equal_string("Object",6))
            break;
        
        inner = s2;//每轮内部循环一定要重新设置inner！！！
        
        while (1)
        {
            if (inner->equal_string("Object",6))
                break;
            outer_name = outer->get_string();
            inner_name = inner->get_string();

            
            //cout<<"outer : " << outer_name<<endl;
            //cout<<"inner : " << inner_name<<endl;
            
            if (! (strcmp(outer_name,inner_name) )) //如果一样，说明当前就是最小公共父类
            {
                //cout<<"find "<<outer_name<<endl;
                return outer;
            } 
            //否则就是没找到，不断追溯内部族谱直到Object
            Symbol inner_parent = gClasslist->nth(find_class(gClasslist,inner))->get_parentname();
            inner = gClasslist->nth(find_class(gClasslist,inner_parent))->get_name();
            
        }
        Symbol outer_parent = gClasslist->nth(find_class(gClasslist,outer))->get_parentname();
        
        //cout<<"outer parent"<<outer_parent->get_string()<<endl;
        
        outer = gClasslist->nth(find_class(gClasslist,outer_parent))->get_name();
        
    }
    return Object;
}

//在目标classes列表中，判断son和parent是否同一类，或者是其子类
int same_or_inherit(Classes classes, Symbol son, Symbol parent){
    Symbol s = son, p = parent;
    while (1)   
    {
        if (same_symbol(p,Object)) //如果待比较的类是Object，那肯定是parent
            return 1;
        if (same_symbol(s, p)) //如果一样，返回1,
            return 1;
        if (same_symbol(s, Object)) //如果s都追溯到Object，还没有从前两个if中退出，那就说明不是parent的子类
            return 0;
        
        //否则，就向上追溯
        //cout<<"s : "<<s->get_string()<<endl;
        s = classes->nth(find_class(classes,s))->get_parentname();
    }
    return -1; //返回-1就是错误，当然，经过了类检查的列表，不可能错误返回
}

//检查两个symbol的名字是否相同
int same_symbol(Symbol s1, Symbol s2){
    char* s1_name = s1->get_string();
    char* s2_name = s2->get_string();
    return !(strcmp(s1_name, s2_name));
}
int same_symbol(Symbol s1, char * s2){
    char* s1_name = s1->get_string();
    return !(strcmp(s1_name, s2));
}

//*************************************
//*************************************
//*************************************
//*************************************

void ClassTable::class_check(){
    class_main_check();
    class_self_type_check();
    class_redefine_check();
    class_inherit_check();
    //全部检查完成后，进行class内部check
    int i = 0;
    Class_ c;
    
    for(i = classlist->first(); classlist->more(i); i = classlist->next(i)){
        c = classlist->nth(i);
        
        //cout<<"\nclass : "<<c->get_name()->get_string()<<endl;

        char* name = c->get_name()->get_string();
        if (!( 
                strcmp(name,"Object")    &&
                strcmp(name,"IO")        &&
                strcmp(name,"Int")       &&
                strcmp(name,"String")    &&
                strcmp(name,"Bool")      
            )) continue; //五种基本类不用检查

        //坏类不用检查
        if (c->bad_flag)
        {
            continue;
        }
        //对每个类检查之前，先开一个scope
        gSymboltable->enterscope();
        
        //将当前类和父类的attr都加入到符号表
        add_all_attr(gSymboltable, gClasslist, c);

        //设置全局变量——当前正在检查的类
        gCurrclass = c;

        //cout<<"attr check begin."<<endl;

        //注意，attr不需要进入新scope
        attr_check(c);
        
        //cout<<"attr check over."<<endl;
        
        //cout<<"method_check begin"<<endl;

        //method内部检查需要进入新scope
        method_check(c);

        //cout<<"method_check"<<endl;
        //每个类检查完毕前夕，回收scope
        gSymboltable->exitscope();
    }
}

//方法检查
void ClassTable::method_check(Class_ c){
    //cout<<gCurrclass->get_name()->get_string()<<endl;
    //cout<<"class name"<< gCurrclass->get_name()->get_string()<<endl;
    Features features = c->get_features();
    
    int i = -1;
    for(i = next_method(features,-1); i>=0 ; i = next_method(features,i)){
        Feature feature = features->nth(i);
        method_class* method = static_cast<method_class*>(feature);
        
        //cout<<"method name : " << method->get_name()->get_string()<<endl;
        
        //每检查一个新函数，都要进入一个scope
        gSymboltable->enterscope();
        
        //在参数检查的时候，将形参加入符号表。这一步要在返回值类型检查之前做，因为返回值类型检查设计expr的检查
        //expr的检查要用到符号表
        method_formals_check(method);
        
        //cout<<"formal check over"<<endl;

        //覆写检查啥时候做都行,没有强制顺序要求
        method_override_check(c,method);
        

        //cout<<"method override check over"<<endl;

        //cout<<"method name:"<<method->get_name()->get_string()<<endl;

        //返回值类型检查必须要在添加形参后才做
        method_return_type_check(c, method);//这个要等到expr检查


        //cout<<"method return type check over"<<endl;

        //在离开这个函数检查的时候，退出scope
        gSymboltable->exitscope();

    }
    
}


//属性检查
void ClassTable::attr_check(Class_ c){
    Features features = c->get_features();
    int i = -1;
    for(i = next_attr(features,-1); i>=0 ; i = next_attr(features,i)){
        Feature feature = features->nth(i);
        attr_class* attr = static_cast<attr_class*>(feature);
        
        //cout<<"attr type check begin"<<endl;
        
        //attr类型检查
        attr_type_check(attr);

        //cout<<"attr override check begin"<<endl;
        //attr继承重定义检查
        attr_override_check(attr);
        
        /*
        后面修改了代码，在进入一个新类之后，就将其和所有祖先的属性都加入符号表，因为可能要用父类成员变量。
        所以逻辑就不是先检查再加入，而是先加入所有属性，再检查当前类属性。
        当然，只有成员变量是这样。
        */
        //该attr检查完毕之后，可以将其加入symboltable了
        //gSymboltable->addid(attr->get_name(), attr->get_type_decl());
        /*
        //测试scope能否使用
        Symbol temp = gSymboltable->lookup(attr->get_name());
        //cout<<attr->get_name()->get_string()<<"   "<<temp->get_string()<<endl;
        */

    }
}


//*************************************
//*************************************
//*************************************
//*************************************




//检查Main类和main方法存在
void ClassTable::class_main_check(){
    int i = 0,j = 0;
    i = find_class(classlist,Main);
    if (i<0){ //如果没有Main类
        semant_error() << "Class Main is not defined.\n";
        return;
    } else { //如果Main定义了
        Features features = classlist->nth(i)->get_features();
        j = find_method(features,main_meth);
        if (j<0)
        {
            semant_error(classlist->nth(i)) << "Method main is not defined.\n";
            return;
        }
    }
    return;
}

//检查SELF_TYPE的定义情况
void ClassTable::class_self_type_check(){
    int i = find_class(classlist,SELF_TYPE);
    if ( i >= 0 )
        //Redefinition of basic class SELF_TYPE.
        semant_error(gfilename, classlist->nth(i)) << "Redefinition of basic class SELF_TYPE."<<endl;
        
}

//检查重定义
void ClassTable::class_redefine_check(){
    //类的重定义
    int i = 0,j = 0,k = 0;
    Class_ class1, class2;
    Symbol class_name1,class_name2;

    for(i = classlist->first(); classlist->more(i); i = classlist->next(i)){
        for(j = i+1; classlist->more(j); j = classlist->next(j)){
            class1 = classlist->nth(i);
            class2 = classlist->nth(j);
            class_name1 = classlist->nth(i)->get_name();
            class_name2 = classlist->nth(j)->get_name();
            if(class_name1->equal_string(class_name2->get_string(),strlen(class_name2->get_string()))){
                //1.基础类重定义
                if (
                    same_symbol(class_name1, Object)    ||
                    same_symbol(class_name1, Int)       ||
                    same_symbol(class_name1, Bool)      ||
                    same_symbol(class_name1, IO)        ||
                    same_symbol(class_name1, Str)
                )
                {
                    //Redefinition of basic class Object.
                    semant_error(gfilename, class1) << "Redefinition of basic class " << class_name1->get_string() <<"."<<endl;
                    return;
                }
                //2.一般类重定义
                else {
                    //Class A was previously defined.
                    semant_error(gfilename, class2) << "Class " << class_name2->get_string() << " was previously defined."<<endl;
                    return;
                }
                
                
                
            }
        }
    }
    
    //方法重定义
    Symbol method_name1,method_name2;
    Features features;
    for(i = classlist->first(); classlist->more(i); i = classlist->next(i)){
        features = classlist->nth(i)->get_features();
        for(j = next_method(features,-1); j>=0 ; j = next_method(features,j)){
            for ( k = next_method(features,j); k>=0 ; k = next_method(features,k))
            {
                method_name1 = features->nth(j)->get_name();
                method_name2 = features->nth(k)->get_name();
                if(method_name1->equal_string(method_name2->get_string(),strlen(method_name2->get_string()))){
                    semant_error() << "method redefined.\n";
                    return;
                }
            }
        }
    }
}
 //继承检查：父类应该存在，且不能是Int/Str/Bool/SELF_TYPE，且不能成环
void ClassTable::class_inherit_check(){
    int i = 0,j = 0;
    Class_ curr_class;
    Symbol parent_name,curr_class_name;
    for(i = classlist->first(); classlist->more(i); i = classlist->next(i)){
        curr_class = classlist->nth(i);
        curr_class_name = curr_class->get_name();
        if (same_symbol(curr_class_name, Object)) //跳过Object类
            continue;
        
        parent_name = classlist->nth(i)->get_parentname();
        
        //先检查类继承问题
        if ( 
                same_symbol(parent_name, Int)        ||
                same_symbol(parent_name, Str)        ||
                same_symbol(parent_name, Bool)       ||
                same_symbol(parent_name, SELF_TYPE)
            )
        {
            //Class B cannot inherit class Bool.
            semant_error(gfilename, curr_class) << "Class " << curr_class_name->get_string() << " cannot inherit class " << parent_name->get_string() << "." <<endl;
            curr_class->bad_flag = 1;
            return;
        }
        //非基础类，检查父类是否存在
        //cout<<"find parent "<< parent_name->get_string()<<endl;

        j = find_class(gClasslist,parent_name);

        //cout<<"after find"<<endl;

        if (j < 0)
        {
            //Class A inherits from an undefined class D.
            semant_error(gfilename, curr_class) << "Class " << curr_class_name->get_string() << " inherits from an undefined class " << parent_name->get_string() << "." <<endl;
            curr_class->bad_flag = 1; //设置坏类标志，意味着方法或属性检查的时候就可以跳过该类
            return;
        }
        //cout<<"after return "<<endl;
    }
    //之前检查都没问题了，再检查成环继承
    for(i = classlist->first(); classlist->more(i); i = classlist->next(i)){
        curr_class_name = classlist->nth(i)->get_name();
        
        if (same_symbol(curr_class_name, Object)) //跳过Object类
            continue;

        parent_name = classlist->nth(i)->get_parentname();

        while(1){
            /*循环结束条件有
            1.父类为Object（正确）
            2.父类又回到当前类i（错误）*/
            if (same_symbol(parent_name, Object))
                break;
            int j = find_class(classlist,parent_name);//前面检查都没问题，那么index一定存在
            if (j == i){ //如果又回到当前检查的i，那么说明成环了
                semant_error() << "Ring inherit.\n";
                return;
            }
            parent_name = classlist->nth(j)->get_parentname();
        }
    }
}



//method相关检查

//函数形参列表检查，包括形参不能含self（self不能做标识符），不重定义，类型应被定义
void ClassTable::method_formals_check(method_class* method){
    Formals formals = method->get_formals();
    Symbol name,type_decl;
    int i = 0,j = 0;
    //先检查self和类型名存在的问题
    for( i = formals->first(); formals->more(i); i = formals->next(i)){
        Formal formal = formals->nth(i);
        name = formals->nth(i)->get_name();
        type_decl = formals->nth(i)->get_type_decl();
        
        
        //形参名字不能是self
        if (name->equal_string("self",strlen("self")))
        {
            //'self' cannot be the name of a formal parameter.
            semant_error(gfilename, formal) << "'self' cannot be the name of a formal parameter."<<endl;
            gSymboltable->addid(name, type_decl);
            return;
        }
        // Formal parameter x cannot have type SELF_TYPE.
        // 形参类型不能是SELF_TYPE，即使真的出现了，也要添加到符号表，类型照常设置，防止别的检查出错
        if (same_symbol(type_decl, "SELF_TYPE"))
        {
            semant_error(gfilename, formal) << "Formal parameter " << name->get_string() << " cannot have type SELF_TYPE." << endl;
            gSymboltable->addid(name, SELF_TYPE);
            return;
        }
        
        if (find_class(classlist,type_decl)<0) { //如果找不到该类型
            semant_error() << "type" << type_decl->get_string() << "doesn't exist.\n";
            //gSymboltable->addid(name, No_type);
            return;
        }

        
        gSymboltable->addid(name, type_decl);
        
    }
    
    //检查参数列表重定义
    char* name1,*name2;
    for( i = formals->first(); formals->more(i); i = formals->next(i)){
        for( j = i+1 ; formals->more(j); j = formals->next(j)){
            Formal formal1 = formals->nth(i);
            Formal formal2 = formals->nth(j);
            name1 = formal1->get_name()->get_string();
            name2 = formal2->get_name()->get_string();
            
            //Formal parameter x is multiply defined.
            //Formal parameter x is multiply defined.
            //错误信息输出两个，应该是为了解决两个形参不在同一行的问题
            if ( !strcmp(name1,name2) ) //名字相同，那就是重复定义了
            {
                semant_error(gfilename, formal1) <<"Formal parameter " << name1 << " is multiply defined." << endl;
                semant_error(gfilename, formal2) <<"Formal parameter " << name2 << " is multiply defined." << endl;
                return;
            }
        }
    }

    //参数列表没问题之后，再加入symboltable
    for( i = formals->first(); formals->more(i); i = formals->next(i)){
        name = formals->nth(i)->get_name();
        type_decl = formals->nth(i)->get_type_decl();
        gSymboltable->addid(name,type_decl);
    }

    //gSymboltable->dump();
}


//函数返回值类型应被定义，并且推导的返回值和声明的返回值应一致
//第一个Class_参数是为了解决SELF_TYPE的问题，需要用到当前
void ClassTable::method_return_type_check(Class_ c, method_class* method){
    //返回类型应该被定义
    
    //cout<<"method return type check"<<endl;

    int ret_self_flag = 0;      //定义的ret类型是否是SELF_TYPE
    int expr_self_flag = 0;     //函数表达式expr的推导类型是否为self类型
    Symbol compared_ret_type;   //用于比较的ret的类型
    Symbol compared_expr_type;  // 用于比较的expr类型


    int index = 0;
    Symbol return_type = method->get_return_type();
    if (return_type->equal_string("SELF_TYPE",strlen("SELF_TYPE"))){
        ret_self_flag = 1;
        compared_ret_type = gCurrclass->get_name();
    }
    else
    {
        compared_ret_type = return_type;
    }

    if (!ret_self_flag)
    {
        index = find_class(classlist, return_type);
        if (index<0)
        {
            //Undefined return type PinkElephant in method main.
            semant_error(gfilename, method) << "Undefined return type " << return_type <<" in method " 
            << method->get_name() << "." << endl;
            //return;//不能return，不然 returntypenoexist.test 会教你做人
        }
    }
    
    
    //一致性
    //注意，返回值可能是self，意思是本类，self是小写，那么会被当成一个标识符，即Symbol，即Object
    //怎么处理Object，就怎么处理self
    //cout<<"method check"<<endl;

    Expression expr = method->get_expr();
    //cout<<"check type"<<endl;
    expr->check_type();
    //cout<<"check type over"<<endl;
    Symbol expr_type = expr->get_type();


    if (same_symbol(expr_type, SELF_TYPE)){
        expr_self_flag = 1;
        compared_expr_type = gCurrclass->get_name();
    }
    else
    {
        compared_expr_type = expr_type;
    }

    //特殊情况：selftypebadreturn.test
    //如果定义的返回类型ret是SELF_TYPE ，但是返回的不是SELF_TYPE，那么
    if (ret_self_flag && !expr_self_flag)
    {
        //Inferred return type A of method foo does not conform to declared return type SELF_TYPE.
        semant_error(gfilename, method)<<"Inferred return type " << compared_expr_type << " of method " << method->get_name()
        << " does not conform to declared return type SELF_TYPE." <<endl;
    }
    

    // 如果不一致，注意，表达式的类型 只要是定义类型 的子类即可
    if (! same_or_inherit(gClasslist,compared_expr_type, compared_ret_type))
    {
        //Inferred return type Z of method h does not conform to declared return type B.
        semant_error(gfilename, method)<<"Inferred return type " << expr_type << " of method " << method->get_name()
        << " does not conform to declared return type " << return_type << "." <<endl;
        return;
    }
    
}

//重定义父类方法，参数列表和返回值应一致。
void ClassTable::method_override_check(Class_ c, method_class* method){
    //初始化
    Class_ curr = c;
    Symbol curr_name = curr->get_name();
    if(curr_name->equal_string("Object",strlen("Object"))){
        return;
    }
    //否者，当前类至少是Object子类

    Symbol target_method_name = method->get_name();
    Features features;
    int i = 0,j = 0;
    
    while (1){
        Symbol parent_name = curr->get_parentname();
        Class_ curr = classlist->nth(find_class(classlist,parent_name));//当前的替换成父类，找method
        features = curr->get_features();
        i = find_method(features, target_method_name);
        if ( i>=0 ) { //如果父类中能找到该方法，则开始比对
            Feature feature = features->nth(i);
            method_class* curr_method = static_cast<method_class*>(feature);
            
            //先比较返回类型
            char* curr_ret_name = curr_method->get_return_type()->get_string();
            char* target_ret_name = method->get_return_type()->get_string();
            if (strcmp(curr_ret_name,target_ret_name)) // 如果返回值不一样
            {
                semant_error() << "return type donesn't match.\n ";
                return;
            }
            //再比较参数列表
            Formals curr_formals = curr_method->get_formals();
            Formals target_formals = method->get_formals();
            //先检查长度
            if( curr_formals->len() != target_formals->len() ){
                //如果有问题，打印的是目标类(target)的问题，而不是当前扫描到的父类(curr)的问题
                //Incompatible number of formal parameters in redefined method foo.
                semant_error(gfilename, target_formals) << "Incompatible number of formal parameters in redefined method " << target_method_name <<"."<<endl;
                return;
            }
            //现在长度一样
            for ( j = curr_formals->first(); curr_formals->more(j); j = curr_formals->next(j)){
                Formal curr_formal = curr_formals->nth(j);
                Formal target_formal = target_formals->nth(j);
                Symbol curr_type_name = curr_formal->get_type_decl();
                Symbol target_type_name = target_formal->get_type_decl();
                if (!same_symbol(curr_type_name,target_type_name)) //如果两个参数列表当前索引类型不一致，说明不对
                {
                    //In redefined method inky, parameter type C is different from original type B
                    semant_error(gfilename, target_formal) << "In redefined method " << curr_method->get_name() << ", parameter type "
                    << target_type_name  <<" is different from original type " << curr_type_name <<endl; //注意，标准输出这里没给句号，很奇怪
                    return;
                }
            }
        }

        if(!(curr_name->equal_string("Object",strlen("Object")))){
            break;
        }
        //否则，继续下一轮循环开始，找父类
    }
}



//属性类型声明应被定义；属性初始化类型声明与推导出的类型应该一致
void ClassTable::attr_type_check(attr_class* attr){
    Symbol name = attr->get_name();
    Symbol type_decl = attr->get_type_decl();
    Expression init = attr->get_init();

    //名字不能是self
    if (same_symbol(name, self))
    {
        //'self' cannot be the name of an attribute.
        semant_error(gfilename, attr) << "'self' cannot be the name of an attribute."<<endl;
        return;
    }
    



    //声明类型应被定义
    int j = find_class(classlist, type_decl);
    if (j<0)
    {
        semant_error() <<type_decl->get_string() << " not define.\n ";
        return;
    }

    //推导类型要和声明的一致
    //注意：如果没有声明，即声明是no_expr，那么声明这块的类型就是"_no_type"
    init->check_type();
    Symbol init_type = init->get_type();
    
    //cout<<"init type: "<<init_type<<endl;

    //如果没有声明，简单return即可
    if (same_symbol(init_type, No_type))
        return;
    
    //只有在 非SELF_TYPE的情况下才需要检查一致性
    if (!same_symbol(init_type, SELF_TYPE))
    {
        //如果不一致
        if (!same_or_inherit(gClasslist, init_type, type_decl))
        {
            semant_error() <<"attr "<<attr->get_name()->get_string()<< " type doesn't match init.\n ";
            return;
        }
    }
    
    return;
}


//属性重定义检查
//Attribute moo is an attribute of an inherited class.
void ClassTable::attr_override_check(attr_class* attr){
    Symbol attr_name = attr->get_name();
    Class_ temp_class = gCurrclass;
    
    while (1)
    {
        //如果检查到头了，就停止
        if (temp_class->get_name()->equal_string("Object",6))
            break;
        //否则，就将temp_class向上追溯一层
        temp_class = gClasslist->nth(find_class(gClasslist,temp_class->get_parentname()));
        Features temp_features = temp_class->get_features();
        
        int index = find_attr(temp_features,attr_name);

        if (index>=0)
        {
            semant_error(gfilename, attr) <<"Attribute "<<attr->get_name()->get_string()
            <<" is an attribute of an inherited class."<<endl;
            return;
        }
    }

}
//下面是对expression的type检查，注意，每个check_type最后都一定要set_type
//每个expr检查完之后，都给当前expr赋type
//那么最终的type就是最后赋的type，

//assign
//检查标识符是否定义，按照规范应该定义；
//检查 assign 语句的返回类型与声明是否一致，按照规范应该一致；

void assign_class::check_type(){
    //cout<<"in assign "<<endl;
    
    Symbol name = get_name();
    Expression expr = get_expr();

    //先检查是否定义，要涉及作用域的问题，很麻烦，先不写了
    //感觉要用一个栈，像函数调用一样，每进入一个小区域，就准备添加新的变量，也即在let语句中才要加入
    //每次退出前，就要弹出局部变量，可以用两个参数，分别记录参数栈和局部变量数量，也即退出时需要弹出的局部变量数量
    //后来经室友启发，原来有SymbolTable这个神奇的东西，完美解决。在symtab.h里面
    
    //检查标识符
    //cout<<"name "<<name->get_string()<<endl;

    if (same_symbol(name, self))
    {
        //Cannot assign to 'self'.
        gClasstable->semant_error(gfilename,this) << "Cannot assign to 'self'." << endl;
        set_type(SELF_TYPE);
        return;
    }
    
    Symbol name_type = gSymboltable->lookup(name);
    //如果没有该标识符
    if (!name_type)
    {
        gClasstable->semant_error(gfilename,this)<<"Assignment to undeclared variable " << name->get_string() <<"."<< endl;
        return;
    }
    
    expr->check_type(); //同时会赋给expr类型

    //cout<<"go in dispatch "<<endl;

    Symbol expr_type = expr->get_type();

    /*
    //cout<<"end dispatch "<<endl;
    //cout<<"expr_type "<<expr_type->get_string() <<endl;
    //cout<<"name_type "<<name_type->get_string() <<endl;
    */
    //如果赋值语句的右边，即表达式类型 不是 左边定义类型的子类，或相等，就错误
    //也即右边必须是左边的子类或相等

    if (same_symbol(expr_type, SELF_TYPE))
    {
        //set_type(name_type)
    }
    


    if (!same_or_inherit(gClasslist, expr_type, name_type))
    {
        //Type A of assigned expression does not conform to declared type B of identifier b.
        gClasstable->semant_error(gfilename,this)<<"Type " << expr_type << " of assigned expression does not conform to declared type "
        << name_type << " of identifier " << name->get_string() << "." <<endl;
        this->set_type(Object);
        return;
    }
    
    this->set_type(expr->get_type());
    //cout<<"end assign"<<endl;
}


/*
静态调用声明的类型是否被定义，仅在静态调用时检查，按照规范应该被定义；
表达式类型是否被定义，按照规范应该被定义；
表达式类型与静态调用的声明是否符合，仅在静态调用时检查，按照规范应该符合；
函数是否被定义，按照规范应该被定义；
实参和形参的类型是否符合，按照规范应该符合；
函数调用的参数数量与定义是否符合，按照规范应该符合；
*/
//e @B.f()调用类B的函数f。但是e的类型必须从属于类B，也就是说必须是类B或B的子类。
/*
    expression: 
      expression '@' TYPEID '.' OBJECTID '(' expression_list1 ')'
    { $$ = static_dispatch($1, $3, $5, $7); }
*/
//  (new C).init(1,true)

void static_dispatch_class::check_type(){
    //其实可以直接写变量名，因为这个函数相当于定义在类里面的
    Expression expr = get_expr();
    Symbol type_name = get_type_name();
    Symbol method_name = get_name();
    Expressions actuals = get_actual();

    //先检查expr，并赋类型
    expr->check_type();
    Symbol expr_type = expr->get_type();
    
    //对实参的每个expr都要检查
    for (int i = actuals->first(); actuals->more(i) ; i = actuals->next(i))
    {
        Expression temp_actual = actuals->nth(i);
        temp_actual->check_type();
    }

    

    //检查表达式类型是否被定义
    //先检查SELF_TYPE
    if (same_symbol( expr_type, SELF_TYPE )){
        if (!same_or_inherit(gClasslist,gCurrclass->get_name(),type_name))
        {
            //Expression type SELF_TYPE does not conform to declared static dispatch type C.
            gClasstable->semant_error(gfilename,this)<<"Expression type SELF_TYPE does not conform to declared static dispatch type " << type_name->get_string() << "." << endl;
            set_type(Object);
            return;
        }
    }
    //再检查平凡表达式类型
    if ( find_class(gClasslist, expr_type) < 0 )
    {
        gClasstable->semant_error(gfilename,this)<<"Expression type "<<expr_type->get_string()<<" not defined." <<endl;
        set_type(Object);
        return;
    }

    //检查声明类型是否被定义（静态特有）
    if ( find_class(gClasslist, type_name) < 0 )
    {
        gClasstable->semant_error(gfilename,this)<<"Expression type "<<expr_type->get_string()<<" not defined." <<endl;
        set_type(Object);
        return;
    }

    //检查表达式类型和声明类型是否符合（静态特有）
    //只需要expr类型是声明类型本身或者子类即可。
    if (!same_or_inherit(gClasslist,expr_type,type_name))
    {
        //如果不是，即类型不符合
        //Expression type A does not conform to declared static dispatch type B.
        gClasstable->semant_error(gfilename,this)<<"Expression type " << expr_type <<
        " does not conform to declared static dispatch type " << type_name <<"." <<endl;
        set_type(Object);
        return;
    }

    //检查函数是否被定义，到调用的类，也即TYPE_ID指示的类去看
    //caller为形式调用者，真正的方法可能在父类中
    Class_ caller = gClasslist->nth(find_class(gClasslist, type_name));
    Class_ real_caller = method_exist(caller, method_name);
    
    if (!real_caller)
    {   
        //该调用的方法不存在
        gClasstable->semant_error()<<"Dispatch to undefined method "<< method_name <<"."<< endl;
        set_type(Object);
        return;
    }

    Features real_features = real_caller->get_features();
    int index = find_method(real_features, method_name);

    //检查实参形参是否符合，callee是被调用的函数，也即函数定义
    Feature callee_feature = real_features->nth(index);
    method_class* callee = static_cast<method_class*>(callee_feature);
    Formals formals = callee->get_formals();
    //cout<<"callee ret type"<<callee->get_return_type()<<endl;
    //如果参数长度不符合，直接出错
    if ( formals->len() != actuals->len()) 
    {
        gClasstable->semant_error(gfilename,this)<<"method "<<callee->get_name()->get_string()<<" called with wrong number of arguments." <<endl;
        set_type(Object);
        return;
        //Method init called with wrong number of arguments.
    }
    
    //检查类型一致
    //In call of method init, type Bool of parameter x does not conform to declared type Int.
    
    for (int i = actuals->first(); actuals->more(i) ; i = actuals->next(i))
    {
        Symbol formal_type = formals->nth(i)->get_type_decl();
        Symbol formal_name = formals->nth(i)->get_name();
        Symbol actual_type = actuals->nth(i)->get_type();
        //如果类型不一致
        if ( ! (formal_type->get_string(), actual_type->get_string()) ) 
        {
            gClasstable->semant_error(gfilename,this)<<"In call of method "<<callee->get_name()->get_string()
            << ", type " << actual_type << " of parameter " << formal_name->get_string()
            << " does not conform to declared type " << formal_type->get_string() << "." <<endl ;
            set_type(Object);
            return;
        }
    }
    
    
    Symbol ret_type = callee->get_return_type();
    this->set_type(ret_type);
    
}
/*
表达式类型是否被定义，按照规范应该被定义；
函数是否被定义，按照规范应该被定义；
实参和形参的类型是否符合，按照规范应该符合；
函数调用的参数数量与定义是否符合，按照规范应该符合；
*/
/*
    expression: 
      OBJECTID '(' expression_list1 ')'
    { $$ = dispatch(object(idtable.add_string("self")), $1, $3); }
    
    | expression '.' OBJECTID '(' expression_list1 ')'
    { $$ = dispatch($1, $3, $5); }
    
*/
void dispatch_class::check_type(){
    //cout<<gCurrclass->get_name()->get_string()<<endl;
    //cout<<"in dispatch "<<get_name()->get_string() <<endl;
    
    Expression expr = get_expr();
    Symbol method_name = get_name();
    Expressions actuals = get_actual();
    
    //先检查expr，并赋类型。注意，expr可能是self，不过，这已经在object_class里面处理成正确的类了
    expr->check_type();
    Symbol expr_type = expr->get_type();
    
    //cout<<"expr_type : " << expr_type->get_string()<<endl;

    //对实参的每个expr都要检查
    for (int i = actuals->first(); actuals->more(i) ; i = actuals->next(i))
    {
        Expression temp_actual = actuals->nth(i);
        temp_actual->check_type();
    }

    //cout<<"in dispatch2"<<endl;


    Class_ caller;

    //检查表达式类型是否被定义
    //如果是SELF_TYPE
    if (same_symbol(expr_type, SELF_TYPE))
    {
        caller = gCurrclass;
    }
    else {
        if ( find_class(gClasslist, expr_type) < 0 )
        {
            gClasstable->semant_error(gfilename,this)<<"Expression type "<<expr_type->get_string()<<" not defined." <<endl;
            set_type(Object);
            return;
        }
        caller = gClasslist->nth(find_class(gClasslist, expr_type));
    }


    //检查函数是否被定义，到调用的类，即expr指示的类（和静态略有不同，静态是TYPE_ID指示的类）
    //注意，调用类找不到，还要向父类追溯
    //cout<<"caller class is "<<caller->get_name()->get_string()<<endl;
    Features features = caller->get_features();
    /*
    int index = find_method(features, name);
    if (index<0)
    {
        //该调用的方法不存在
        //here

        gClasstable->semant_error(gfilename,this)<<"Dispatch to undefined method "<< name->get_string() <<"."<< endl;
        this->set_type(Object);
        return;
    }
    */
    //cout<<"caller : "<<caller->get_name()->get_string()<<endl;
    Class_ target_class = method_exist(caller, method_name);
    //cout<<"target_class : "<<target_class->get_name()->get_string()<<endl;
    if (!target_class)
    {
        gClasstable->semant_error(gfilename,this)<<"Dispatch to undefined method "<< name->get_string() <<"."<< endl;
        set_type(Object);
        return;
    }

    features = target_class->get_features();
    int index = find_method(features, method_name);
    //cout<<"caller : "<<caller->get_name()->get_string()<<endl;
    //cout<<"method index : "<<index<<endl;

    //检查实参形参是否符合
    Feature callee_feature = target_class->get_features()->nth(index);
    method_class* callee = static_cast<method_class*>(callee_feature);
    Formals formals = callee->get_formals();

    //cout<<"here"<<endl;

    //如果参数长度不符合，直接出错
    if ( formals->len() != actuals->len()) 
    {
        gClasstable->semant_error(gfilename,this)<<"method "<<callee->get_name()->get_string()<<" called with wrong number of arguments." <<endl;
        return;
        //Method init called with wrong number of arguments.
    }
    

    //检查类型一致
    //cout<<"in dispatch : " << method_name <<endl;

    for (int i = actuals->first(); actuals->more(i) ; i = actuals->next(i))
    {
        Symbol formal_type = formals->nth(i)->get_type_decl();
        Symbol formal_name = formals->nth(i)->get_name();
        Symbol actual_type = actuals->nth(i)->get_type();

        //先处理特殊类型SELF_TYPE
        if (same_symbol(actual_type, SELF_TYPE))
        {
            //cout<<"act type"<<actual_type<<endl;
            Symbol temp_type = gCurrclass->get_name();
            //if (!same_symbol(formal_type, temp_type))
            //实参是形参的子类均可
            if (!same_or_inherit(gClasslist, temp_type, formal_type))
            {
                //In call of method init, type Bool of parameter x does not conform to declared type Int.
                gClasstable->semant_error(gfilename,this)<<"In call of method "<<callee->get_name()
                << ", type " << SELF_TYPE << " of parameter " << formal_name
                << " does not conform to declared type " << formal_type << "." <<endl ;
                set_type(Object);
                return;
            }
        }
        //如果实参不是SELF_TYPE类型的
        else 
        {
            //if (!same_symbol(formal_type, actual_type))
            //cout<<"formal type : "<< formal_type<<endl;
            //cout<<"actual type : "<< actual_type<<endl;
            if (!same_or_inherit(gClasslist, actual_type, formal_type))
            {
                gClasstable->semant_error(gfilename,this)<<"In call of method "<<callee->get_name()->get_string()
                << ", type " << actual_type << " of parameter " << formal_name->get_string()
                << " does not conform to declared type " << formal_type->get_string() << "." <<endl ;
                set_type(Object);
                return;
            }
        }
    }
    
    //cout<<callee->get_name()->get_string()<<endl;
    Symbol ret_type = callee->get_return_type();
    
    
    
    //cout<<"caller type: "<<caller->get_name()->get_string()<<endl;
    //如果定义函数的地方，返回值是SELF_TYPE，那就设为调用者的类型
    //cout<<"method name "<<method_name->get_string()<<endl;
    //cout<<"expr_type "<<expr_type->get_string()<<endl;
    
    /*
    if (same_symbol(expr_type, SELF_TYPE))
    {
        set_type(SELF_TYPE);
        //cout<<"end1"<<endl;
        return;
    }
    
    if (same_symbol(ret_type, SELF_TYPE))
    {
        set_type(caller->get_name());
        //cout<<"end2"<<endl;
        return;
    }
    */
    //如果expr_type有自己的类型，且函数本身定义时返回SELF_TYPE，就用调用者的类型
    if (!same_symbol(expr_type, SELF_TYPE) && same_symbol(ret_type, SELF_TYPE))
    {
        set_type(expr_type);
        return;
    }
    
    //cout<<"heer"<<endl;
    //cout<<"ret_type: "<<ret_type<<endl;
    set_type(ret_type);
    
}


//cond和loop检查条件表达式返回类型是否是Bool类型；


void cond_class::check_type(){
    
    if (same_symbol(gCurrclass->get_name(), "Main"))
    {
        //cout<<"in cond"<<endl;
    }
    
    Expression pred = get_pred();
    Expression then_exp = get_then_exp();
    Expression else_exp = get_else_exp();
    pred->check_type();
    Symbol pred_type = pred->get_type();
    
    //cout<<"pred_type "<<pred_type<<endl;

    
    if (!same_symbol(pred_type, Bool)) //如果不是Bool
    {
        
        gClasstable->semant_error(gfilename,this)<<"Cond condition does not have type Bool."<<endl;
        set_type(Object);
        return;
    }
    
    then_exp->check_type();
    else_exp->check_type();

    if (same_symbol(gCurrclass->get_name(), "Main"))
    {
        //cout<<"after else check"<<endl;
    }
    

    Symbol then_type = then_exp->get_type();
    Symbol else_type = else_exp->get_type();
    Symbol same_type;
    //如果then是SELF_TYPE
    if (same_symbol(then_type, SELF_TYPE))
    {
        //如果then 和 else 都是SELF_TYPE
        if (same_symbol(else_type, SELF_TYPE))
            same_type = gCurrclass->get_name();
        //如果then是SELF_TYPE，else不是
        else
            same_type = lowest_common_ancestor(else_type,gCurrclass->get_name());
    }
    //如果then不是SELF_TYPE
    else
    {
        //如果then不是 else 是SELF_TYPE
        if (same_symbol(else_type, SELF_TYPE))
            same_type = lowest_common_ancestor(then_type,gCurrclass->get_name());
        //如果then，else都不是
        else
            same_type = lowest_common_ancestor(then_type,else_type);
    }
    
    

    if (same_symbol(gCurrclass->get_name(), "Main"))
    {
        //cout<<"then_type: "<<then_type->get_string()<<endl;
        //cout<<"else_type: "<<else_type->get_string()<<endl;
        //cout<<"same_type: "<<same_type->get_string()<<endl;
    }
    
    //cout<<"then_type: "<<then_type->get_string()<<endl;
    //cout<<"else_type: "<<else_type->get_string()<<endl;
    //cout<<"same_type: "<<same_type->get_string()<<endl;
    


    this->set_type(same_type);
    
    //cout<<"in cond type is: "<<same_type->get_string()<<endl;

}

void loop_class::check_type(){
    Expression pred = get_pred();
    Expression body = get_body();
    //cout<<"in loop"<<endl;

    pred->check_type();

    Symbol pred_type = pred->get_type();

    if (!same_symbol(pred_type, Bool))
    {
        //Loop condition does not have type Bool
        gClasstable->semant_error(gfilename,this)<<"Loop condition does not have type Bool."<<endl;
        set_type(Object);
        return;
    }

    body->check_type();
    //注意，循环语句的静态类型为Object
    this->set_type(Object);
}


//检查是否存在重复分支
void typcase_class::check_type(){
    //case的静态类型是所有branch的expr的静态类型的并，也即公共父类
    int i = 0, j = 0;
    Expression expr = get_expr();
    Cases cases = get_cases();

    expr->check_type();
    //cout<<"case check"<<endl;
    
    //1,2两个步骤，必须先检查重复分支，然后再检查内部表达式

    //1.检查是否存在重复分支
    for ( i = cases->first(); cases->more(i); i = cases->next(i))
    {
        for ( j = i + 1 ; cases->more(j); j = cases->next(j))
        {
            branch_class* b1 = static_cast<branch_class*>(cases->nth(i));
            branch_class* b2 = static_cast<branch_class*>(cases->nth(j));
            //char* b1_name = b1->get_name()->get_string();
            //char* b2_name = b2->get_name()->get_string();
            char* b1_name = b1->get_type_decl()->get_string();
            char* b2_name = b2->get_type_decl()->get_string();
            
            //cout<<"b1_name " << b1_name<<endl;
            //cout<<"b2_name " << b2_name<<endl;

            //Duplicate branch Int in case statement.
            if (!strcmp(b1_name,b2_name)) // 如果两个标识符相同，错误
            {
                gClasstable->semant_error(gfilename,this)<<"Duplicate branch " << b1_name << " in case statement."<<endl;
                set_type(Object);
                return;
            }
        }
    }

    //cout<<"inner check"<<endl;



    //2.对每个branch的内部expr检查
    //初始化ret_type，cases的每一个元素都是一个branch，且至少有一个branch
    Case case_ = cases->nth(0);
    branch_class* branch = static_cast<branch_class*>(case_);
    branch->check_type();
    Symbol ret_type = branch->get_type();
    for ( i = cases->first(); cases->more(i); i = cases->next(i)){
        case_ = cases->nth(i);
        branch = static_cast<branch_class*>(case_);
        
        //进入case分支，相当于新开一个scope
        gSymboltable->enterscope();
        
        branch->check_type();

        gSymboltable->exitscope();

        //每次都是两个公共最小父类作为返回类型
        ret_type = lowest_common_ancestor(ret_type, branch->get_type() );

    }
    set_type(ret_type);

    /*
    Case temp_case = cases->nth(0);
    branch_class* temp_branch = static_cast<branch_class*>(temp_case);
    Expression temp_expr = temp_branch->get_expr();
    temp_expr->check_type();
    Symbol ret_type = temp_expr->get_type();
    //检查每个branch的expr
    //注意，因为branch继承的是Case_class，但是后者没有set_type，
    //所以就没办法用branch_class的检查函数，因为branch没办法设置、获取type
    for ( i = cases->first(); cases->more(i); i = cases->next(i))
    {
        temp_case = cases->nth(i);
        temp_branch = static_cast<branch_class*>(temp_case);
        temp_expr = temp_branch->get_expr();
        temp_expr->check_type();
        ret_type = find_same_parent_type(ret_type,temp_expr->get_type());
    }
    
    this->set_type(ret_type);
    */
}

void branch_class::check_type(){
    Symbol name = get_name();
    Symbol type_decl = get_type_decl();
    Expression expr = get_expr();

    //先将case语句的临时变量加入
    gSymboltable->addid(name, type_decl);

    expr->check_type();
    Symbol ret_type = expr->get_type();
    
    set_type(ret_type);
}


//block里的expressions一定是非空的
void block_class::check_type(){
    Expressions exprs = get_body();
    int i = 0;
    Symbol ret_type;
    //cout<<"block len "<<exprs->len()<<endl;
    for ( i = exprs->first() ; exprs->more(i) ; i = exprs->next(i)){
        Expression expr = exprs->nth(i);
        //cout<<"expr :"<<i<<endl;
        expr->check_type();
        ret_type = expr->get_type();
    }
    //cout<<"can't go here"<<endl;
    this->set_type(ret_type);
}

//检查标识符声明的类型是否被定义；
//检查标识符初始化过程中被推导出的类型是否与声明相符；
void let_class::check_type(){
    Symbol identifier = get_identifier();
    Symbol type_decl = get_type_decl();
    Expression init = get_init();
    Expression body = get_body();
    
    //cout<<"in let -----------" <<endl;

    if (same_symbol(identifier, self)){

        //'self' cannot be bound in a 'let' expression.
        gClasstable->semant_error(gfilename,this)<<"'self' cannot be bound in a 'let' expression."<<endl;
        set_type(type_decl);
        return;
    }

    //类型定义
    //先处理特殊类型SELF_TYPE
    
    if (same_symbol(type_decl, SELF_TYPE)){
        set_type(SELF_TYPE);
    } 
    else {
        //只有非SELF_TYPE类型才需要找
        int i = find_class(gClasslist, type_decl);
        //cout<<"i : "<<i<<endl;
        //cout<<"type : "<< type_decl->get_string() <<endl;
        if (i<0)
        {
            gClasstable->semant_error(gfilename,this)<<"return type " << type_decl << " not defined."<<endl;
            set_type(Object);
            return;
        }
    }

    //-------------
    //每次进入let语句，都要新开scope
    gSymboltable->enterscope();
    //如果当前类型被定义，那就是可用，那么当前符号就可以加到symboltable了
    gSymboltable->addid(identifier, type_decl);


    //cout<<"id : "<<identifier->get_string()<<endl;
    //cout<<"type : "<<type_decl->get_string()<<endl;
    //cout<<endl;


    //检查内部表达式，会引起递归调用
    init->check_type();
    body->check_type();
    
    
    //---------------

    //检查推导类型
    Symbol init_type = init->get_type();
    Symbol ret_type = body->get_type();

    //cout<<"ret_type : "<<ret_type<<endl;


    char* init_type_str = init_type->get_string();
    
    //如果没有let中局部变量没有初始化，那init就是_no_type
    if (same_symbol(init_type,No_type))
    {
        init_type = type_decl;
    }
    

    //初始化类型只要是声明类型的子类即可。
    if (!same_or_inherit(gClasslist, init_type, type_decl))
    {
        //Inferred type A of initialization of x does not conform to identifier's declared type B.
        gClasstable->semant_error(gfilename,this)<< "Inferred type " << init_type << " of initialization of " <<
        identifier << " does not conform to identifier's declared type " << type_decl << "." <<endl;
        set_type(Object);
        return;
    }
    
    //cout<<"......"<<endl;

    //设置表达式静态类型
    this->set_type(ret_type);
    
    //从let退出，要退出scope
    gSymboltable->exitscope();
    
}

void plus_class::check_type(){
    
    Expression e1 = get_e1();
    Expression e2 = get_e2();
    e1->check_type();
    e2->check_type();
    Symbol e1_type = e1->get_type();
    Symbol e2_type = e2->get_type();

    //如果不是int
    if (!same_symbol(e1_type, Int) || !same_symbol(e2_type, Int)) 
    {
        //non-Int arguments: Int + String
        gClasstable->semant_error(gfilename,this)<<"non-Int arguments: " << e1_type << " + " << e2_type <<endl;
        set_type(Object);
        return;
    }

    this->set_type(Int);
}

void sub_class::check_type(){
    Expression e1 = get_e1();
    Expression e2 = get_e2();
    e1->check_type();
    e2->check_type();
    Symbol e1_type = e1->get_type();
    Symbol e2_type = e2->get_type();

    //如果不是int
    if (!same_symbol(e1_type, Int) || !same_symbol(e2_type, Int)) 
    {
        //non-Int arguments: Int + String
        gClasstable->semant_error(gfilename,this)<<"non-Int arguments: " << e1_type << " - " << e2_type <<endl;
        set_type(Object);
        return;
    }

    this->set_type(Int);
}

void mul_class::check_type(){
    Expression e1 = get_e1();
    Expression e2 = get_e2();
    e1->check_type();
    e2->check_type();
    Symbol e1_type = e1->get_type();
    Symbol e2_type = e2->get_type();

    //如果不是int
    if (!same_symbol(e1_type, Int) || !same_symbol(e2_type, Int)) 
    {
        gClasstable->semant_error(gfilename,this)<<"non-Int arguments: " << e1_type << " * " << e2_type <<endl;
        set_type(Object);
        return;
    }

    this->set_type(Int);
}

void divide_class::check_type(){
    Expression e1 = get_e1();
    Expression e2 = get_e2();
    e1->check_type();
    e2->check_type();
    Symbol e1_type = e1->get_type();
    Symbol e2_type = e2->get_type();

    //如果不是int
    if (!same_symbol(e1_type, Int) || !same_symbol(e2_type, Int)) 
    {
        gClasstable->semant_error(gfilename,this)<<"non-Int arguments: " << e1_type << " / " << e2_type <<endl;
        set_type(Object);
        return;
    }

    this->set_type(Int);

}

// ~
void neg_class::check_type(){
    Expression e1 = get_e1();
    e1->check_type();
    Symbol e1_type = e1->get_type();

    if (!same_symbol(e1_type, Int)) //如果不是int
    {
        gClasstable->semant_error(gfilename,this)<<"non-Int arguments: ~" << e1_type <<endl;
        set_type(Object);
        return;
    }

    this->set_type(Int);    
}

// < 
void lt_class::check_type(){
    Expression e1 = get_e1();
    Expression e2 = get_e2();
    e1->check_type();
    e2->check_type();
    Symbol e1_type = e1->get_type();
    Symbol e2_type = e2->get_type();

    //如果不是int
    if (!same_symbol(e1_type, Int) || !same_symbol(e2_type, Int)) 
    {
        gClasstable->semant_error(gfilename,this)<<"non-Int arguments: " << e1_type << " < " << e2_type <<endl;
        set_type(Object);
        return;
    }

    this->set_type(Bool);

}

// = ,`Int`、`Bool` 或者 `String` 对应即可
void eq_class::check_type(){
    Expression e1 = get_e1();
    Expression e2 = get_e2();

    e1->check_type();
    e2->check_type();

    Symbol e1_type = e1->get_type();
    Symbol e2_type = e2->get_type();

    int case1 = e1_type->equal_string("Int",3) && e2_type->equal_string("Int",3);
    int case2 = e1_type->equal_string("Bool",4) && e2_type->equal_string("Bool",4);
    int case3 = e1_type->equal_string("String",6) && e2_type->equal_string("String",6);

    if (case1 || case2 || case3)
    {
        this->set_type(Bool);
    } else {
        //如果不是合法的基本类型比较
        if (    //如果出现了基本类型那就说明有错
            same_symbol(e1_type,Int) || same_symbol(e1_type,Bool) || same_symbol(e1_type,Str) || 
            same_symbol(e2_type,Int) || same_symbol(e2_type,Bool) || same_symbol(e2_type,Str)
            )
        {
            //Illegal comparison with a basic type.
            gClasstable->semant_error(gfilename,this)<<"Illegal comparison with a basic type."<<endl;
            set_type(Object);
            return;
        }
        else
        {
            set_type(Bool);
        }
    }
    
    return;
}


// <=
void leq_class::check_type(){
    Expression e1 = get_e1();
    Expression e2 = get_e2();
    e1->check_type();
    e2->check_type();
    Symbol e1_type = e1->get_type();
    Symbol e2_type = e2->get_type();

    //如果不是int
    if (!same_symbol(e1_type, Int) || !same_symbol(e2_type, Int)) 
    {
        gClasstable->semant_error(gfilename,this)<<"non-Int arguments: " << e1_type << " <= " << e2_type <<endl;
        set_type(Object);
        return;
    }

    this->set_type(Bool);
}

//not,检查参数类型是否为 `Bool` 类型；
void comp_class::check_type(){
    Expression e1 = get_e1();
    e1->check_type();
    Symbol e1_type = e1->get_type();

    if (!same_symbol(e1_type, Bool)) //如果不是Bool
    {
        gClasstable->semant_error(gfilename,this)<<"non-Bool arguments: not " << e1_type << endl;
        set_type(Object);
        return;
    }

    this->set_type(Bool);   
}

void int_const_class::check_type(){
    this->set_type(Int);
}

void bool_const_class::check_type(){
    this->set_type(Bool);
}

void string_const_class::check_type(){
    this->set_type(Str);
}

//检查 new 是否被用于未定义的类，按照规范不应该；
void new__class::check_type(){
    Symbol type_name = get_type_name();
    int index = 0;
    //先判断SELF_TYPE
    if (same_symbol(type_name, SELF_TYPE))
    {
        /*
        //这个检查没必要，简单设置SELF_TYPE即可
        index = find_class(gClasslist, gCurrclass->get_name());
        if (index<0)
        {
            gClasstable->semant_error(gfilename,this)<<"type not defined."<<endl;
            set_type(Object);
            return;
        }
        */
        
        set_type(SELF_TYPE);
        return ;
    }
    

    //再处理其余类型
    index = find_class(gClasslist, type_name);
    if (index<0)
    {
        //'new' used with undefined class PinkElephant.
        gClasstable->semant_error(gfilename,this)<<"'new' used with undefined class " << type_name << "."<<endl;
        set_type(type_name);
        return;
    }

    set_type(type_name);
}

//是否为空，注意，为Bool类型
void isvoid_class::check_type(){
    Expression e1 = get_e1();
    e1->check_type();

    this->set_type(Bool);
}

//空表达式的类型是No_type
void no_expr_class::check_type(){
    this->set_type(No_type);
}

//检查标识符是否被声明
void object_class::check_type(){

    Symbol name = get_name();
    //cout<<"name : "<<name->get_string()<<endl;

    //cout<<"name : "<< name->get_string()<<" type : "<<type_name->get_string()<<endl;
    //一个标识符最终返回的类型，就是这个标识符的类
    //这里先处理self_type
    if (same_symbol(name, self))//如果是self
    {
        this->set_type(SELF_TYPE);
        return;
    }

    //cout<<"Object "<<name->get_string()<<endl;
    
    Symbol type_name = gSymboltable->lookup(name);
    
    if (!type_name)
    {
        gClasstable->semant_error(gfilename,this)<<"Undeclared identifier "<<name->get_string()<< "."<<endl;
        set_type(Object);
        return;
    }
    set_type(type_name);
    
}

