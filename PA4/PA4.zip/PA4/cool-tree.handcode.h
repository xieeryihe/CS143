//
// The following include files must come first.

#ifndef COOL_TREE_HANDCODE_H
#define COOL_TREE_HANDCODE_H

#include <iostream>
#include "tree.h"
#include "cool.h"
#include "stringtab.h"
#define yylineno curr_lineno;
extern int yylineno;

inline Boolean copy_Boolean(Boolean b) {return b; }
inline void assert_Boolean(Boolean) {}
inline void dump_Boolean(ostream& stream, int padding, Boolean b)
	{ stream << pad(padding) << (int) b << "\n"; }

void dump_Symbol(ostream& stream, int padding, Symbol b);
void assert_Symbol(Symbol b);
Symbol copy_Symbol(Symbol b);

class Program_class;
typedef Program_class *Program;
class Class__class;
typedef Class__class *Class_;
class Feature_class;
typedef Feature_class *Feature;
class Formal_class;
typedef Formal_class *Formal;
class Expression_class;
typedef Expression_class *Expression;
class Case_class;
typedef Case_class *Case;

typedef list_node<Class_> Classes_class;
typedef Classes_class *Classes;
typedef list_node<Feature> Features_class;
typedef Features_class *Features;
typedef list_node<Formal> Formals_class;
typedef Formals_class *Formals;
typedef list_node<Expression> Expressions_class;
typedef Expressions_class *Expressions;
typedef list_node<Case> Cases_class;
typedef Cases_class *Cases;

#define METHOD 260
#define ATTR 261

#define Program_EXTRAS                          \
virtual void semant() = 0;			\
virtual void dump_with_types(ostream&, int) = 0; 



#define program_EXTRAS                          \
void semant();     				\
void dump_with_types(ostream&, int);            

#define Class__EXTRAS                   			\
virtual Symbol get_name() = 0;						\
virtual Symbol get_parentname() = 0;				\
virtual Features get_features() = 0;				\
virtual Symbol get_filename() = 0;      			\
virtual void dump_with_types(ostream&,int) = 0; 	\
int bad_flag = 0;


#define class__EXTRAS                               \
Symbol get_name()	{ return name; }				\
Symbol get_parentname()	{ return parent; }			\
Features get_features() { return features; }		\
Symbol get_filename() { return filename; }          \
void dump_with_types(ostream&,int);

#define Feature_EXTRAS                             \
virtual Symbol get_name() = 0;					      \
virtual int get_feature_type() = 0;                \
virtual void dump_with_types(ostream&,int) = 0; 	


#define Feature_SHARED_EXTRAS                      \
Symbol get_name() { return name; }					   \
void dump_with_types(ostream&,int);    

//method 和 attr 就不用dump了，因为在Feature的宏中已经dump写过了

#define method_EXTRAS                              \
Formals get_formals() { return formals; }          \
Symbol get_return_type() { return return_type; }   \
Expression get_expr() { return expr; }             \
int get_feature_type() { return METHOD; }


#define attr_EXTRAS                                \
Symbol get_type_decl() { return type_decl; }       \
Expression get_init() { return init; }             \
int get_feature_type() { return ATTR; }


#define Formal_EXTRAS                              \
virtual Symbol get_name() = 0;                     \
virtual Symbol get_type_decl() = 0;                \
virtual void dump_with_types(ostream&,int) = 0;


#define formal_EXTRAS                              \
Symbol get_name() { return name; }                 \
Symbol get_type_decl() { return type_decl; }       \
void dump_with_types(ostream&,int);



//-------------------------------------------

#define Expression_EXTRAS                    		\
Symbol type;                                 		\
Symbol get_type() { return type; }           		\
Expression set_type(Symbol s) { type = s; return this; } \
virtual void dump_with_types(ostream&,int) = 0;  	\
void dump_type(ostream&, int);               		\
Expression_class() { type = (Symbol) NULL; }		\
virtual void check_type() = 0;


#define Expression_SHARED_EXTRAS           			\
void dump_with_types(ostream&,int);					\
void check_type();


//----------------

//branch_class 的父类是 Case_class，
//typcase_class 的父类是 Expression_class
//所以返回type的分辨只需要在typcase_class中做就行了
//当然，开头大写的都是虚函数或声明（除了Expression）
#define Case_EXTRAS                                		\
virtual Symbol get_name() = 0;							\
virtual Symbol get_type_decl() = 0;						\
virtual void dump_with_types(ostream& ,int) = 0;		\
virtual void check_type() = 0;

//Case_class 只有一个子类，所以不需要定义Shared_EXTRAS
//但是就是因为不是继承自Expression，所以要自己定义一个type，以及相关的set和get
//和Expression_EXTRAS一样
#define branch_EXTRAS                                   \
Symbol get_name() { return name; }						\
Symbol get_type_decl() { return type_decl; }			\
Expression get_expr() { return expr; }					\
void dump_with_types(ostream& ,int);					\
void check_type();										\
Symbol type;											\
Symbol get_type() { return type; }						\
void set_type(Symbol s) { type = s; }



//接下来就全是继承自Expression的了，但是除了get_expr_type能
//直接用之外，其余子类独特的函数都需要先强转，再用


#define assign_EXTRAS									\
Symbol get_name() { return name; }						\
Expression get_expr() { return expr; }					

#define static_dispatch_EXTRAS							\
Expression get_expr() { return expr; }					\
Symbol get_type_name() { return type_name; }			\
Symbol get_name() { return name; } 						\
Expressions get_actual() { return actual; }				

#define dispatch_EXTRAS									\
Expression get_expr() { return expr; }					\
Symbol get_name() { return name; } 						\
Expressions get_actual() { return actual; }				

#define cond_EXTRAS										\
Expression get_pred() { return pred; }					\
Expression get_then_exp() { return then_exp; }			\
Expression get_else_exp() { return else_exp; }			

#define loop_EXTRAS										\
Expression get_pred() { return pred; }					\
Expression get_body() { return body; }

#define typcase_EXTRAS									\
Expression get_expr() { return expr; }					\
Cases get_cases() { return cases; }								

#define block_EXTRAS									\
Expressions get_body() { return body; }

#define let_EXTRAS										\
Symbol get_identifier() { return identifier; }			\
Symbol get_type_decl() { return type_decl; }			\
Expression get_init() { return init; }					\
Expression get_body() { return body; }

//下面是基础运算
#define plus_EXTRAS										\
Expression get_e1() { return e1; }						\
Expression get_e2() { return e2; }

#define sub_EXTRAS										\
Expression get_e1() { return e1; }						\
Expression get_e2() { return e2; }

#define mul_EXTRAS										\
Expression get_e1() { return e1; }						\
Expression get_e2() { return e2; }

#define divide_EXTRAS										\
Expression get_e1() { return e1; }						\
Expression get_e2() { return e2; }

#define neg_EXTRAS										\
Expression get_e1() { return e1; }

#define lt_EXTRAS										\
Expression get_e1() { return e1; }						\
Expression get_e2() { return e2; }

#define eq_EXTRAS										\
Expression get_e1() { return e1; }						\
Expression get_e2() { return e2; }

#define leq_EXTRAS										\
Expression get_e1() { return e1; }						\
Expression get_e2() { return e2; }

#define comp_EXTRAS										\
Expression get_e1() { return e1; }

//一些const

#define int_const_EXTRAS								\
Symbol get_token() { return token; }

#define bool_const_EXTRAS								\
Boolean get_val() { return val; }

#define string_const_EXTRAS								\
Symbol get_token() { return token; }


//
#define new__EXTRAS	 	   								\
Symbol get_type_name() { return type_name; }

#define isvoid_EXTRAS									\
Expression get_e1() { return e1; }

// #define no_expr_EXTRAS									

#define object_EXTRAS									\
Symbol get_name() { return name; }

#endif

