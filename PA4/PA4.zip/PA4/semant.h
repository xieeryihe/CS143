#ifndef SEMANT_H_
#define SEMANT_H_

#include <assert.h>
#include <iostream>  
#include "cool-tree.h"
#include "stringtab.h"
#include "symtab.h"
#include "list.h"

#define TRUE 1
#define FALSE 0

class ClassTable;
typedef ClassTable *ClassTableP;
//全局变量，方便check_type检查

Classes gClasslist;
ClassTableP gClasstable;
Symbol gfilename;
Class_ gCurrclass;    //当前正在检查的类

//将Symbol映射为Symbol，实际上前一个是变量名，后一个是变量类型，这两个都可以是Symbol或者char*
//当然，因为addid函数第二个参数，也就是模板SymbolTable的第二个类型是DAT*，也就是说会多加一层指针，所以定义的时候就给第二个类型少加一层指针
//这个可以查看符号表的定义，并且写代码测试一下
SymbolTable<Symbol,Entry>* gSymboltable;
/*
有三种情况需要加入新的（定义过的）变量
1.类定义的attr
2.进入函数method的局部变量
3.let语句定义的expr
*/


// This is a structure that may be used to contain the semantic
// information such as the inheritance graph.  You may use it or not as
// you like: it is only here to provide a container for the supplied
// methods.

  //辅助函数

int find_class(Classes classes, char* class_name);
int find_class(Classes classes, Symbol class_name);
Class_ get_parent_class(Classes classes, Class_ c);
int next_method(Features features, int i);//找i索引的下一个方法
int next_attr(Features features, int i);//找i索引的下一个属性
int find_method(Features features, char* method_name);
int find_method(Features features, Symbol method_name);
Class_ method_exist(Class_ c, Symbol s);  //目标类及其祖先中找对应方法，找到则返回对应类，否则为NULL
int find_attr(Features features, char* attr_name);
int find_attr(Features features, Symbol attr_name);


void add_all_attr(SymbolTable<Symbol,Entry>* t, Classes classes, Class_ c); //在目标classes中，将c及其祖先的所有attr加入到符号表t中

Symbol lowest_common_ancestor(Symbol s1, Symbol s2); // 找最小的共同父类
int same_or_inherit(Classes classes, Symbol son, Symbol parent); //在目标classes列表中，判断son和parent是否同一类，或者是其子类

int same_symbol(Symbol s1, Symbol s2);  //检查两个symbol的名字是否相同
int same_symbol(Symbol s1, char * s2);  //重载

class ClassTable {
private:
  int semant_errors;
  void install_basic_classes();
  ostream& error_stream;
  
public:
  Classes classlist; //my list
  ClassTable(Classes);
  int errors() { return semant_errors; }
  ostream& semant_error();
  ostream& semant_error(Class_ c);
  ostream& semant_error(Symbol filename, tree_node *t);

  //class 相关检查
  void class_check();         //程序检查
  void class_main_check();      //main函数相关检查
  void class_self_type_check();  //检查：不能定义SELF_TYPE类
  void class_redefine_check();  //类和方法重定义检查
  void class_inherit_check();   //继承检查：父类应该存在，且不能是Int/Str/Bool/SELF_TYPE，且不能成环

  //method 相关检查
  void method_check(Class_ c);            //method综合检查
  void method_formals_check(method_class* method);    //函数形参列表检查，包括形参不能含self，不重定义，类型应被定义
  void method_return_type_check(Class_ c, method_class* method);//函数返回值类型应被定义，并且推导的返回值和声明的返回值应一致
  void method_override_check(Class_ c, method_class* method);   //重定义父类方法，参数列表和返回值应一致。

  //attribute 相关检查
  void attr_check(Class_ c);      
  void attr_type_check(attr_class* attr);     //属性类型声明应被定义；属性初始化类型声明与推导出的类型应该一致
  void attr_override_check(attr_class* attr); //属性重定义检查
  //expression 相关检查


  
};


#endif
